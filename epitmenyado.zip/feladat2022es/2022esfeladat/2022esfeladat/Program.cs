﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Security.Policy;

class Program
{
    static void Main()
    {
        // Fájl elérési útja
        string filePath = "utca.txt";

        // Listában tároljuk az adatokat
        List<string> data = new List<string>();

        try
        {
            // Fájl olvasása
            using (StreamReader sr = new StreamReader(filePath))
            {
                string line;

                // Soronkénti beolvasás és tárolás
                while ((line = sr.ReadLine()) != null)
                {
                    data.Add(line);
                }
            }

            // Telek számának számolása
            int telekCount = data.Count;

            // Kiíratás a telek számáról
            Console.WriteLine($"A telek száma az állományban: {telekCount}");

            // Tulajdonos adószámának bekérése
            Console.Write("Kérem adja meg a tulajdonos adószámát: ");
            string adoszam = Console.ReadLine();

            // Keresés az adatok között
            bool talalt = false;
            foreach (string sor in data)
            {
                string[] adatok = sor.Split(';');
                if (adatok.Length == 3 && adatok[0].Trim() == adoszam)
                {
                    talalt = true;
                    string utca = adatok[1].Trim();
                    string hazszam = adatok[2].Trim();
                    Console.WriteLine($"Az adott adószámhoz tartozó épület az {utca} utcában, {hazszam} házszám alatt található.");

                    // Adósáv és alapterület bekérése
                    Console.Write("Kérem adja meg az adósávot: ");
                    double adosav = Convert.ToDouble(Console.ReadLine());

                    Console.Write("Kérem adja meg az alapterületet: ");
                    double alapterulet = Convert.ToDouble(Console.ReadLine());

                    // Adó kiszámítása és kiíratása
                    double ado = SzamolAdot(adosav, alapterulet);
                    Console.WriteLine($"Az épület után fizetendő adó: {ado} Ft");
                    break;
                }
            }

            // Ha nem találta meg az adott adószámot az adatok között
            if (!talalt)
            {
                Console.WriteLine("A megadott adószám nem szerepel az adatállományban.");
            }
        }
        catch (Exception e)
        {
            // Hiba esetén kiírjuk a hibaüzenetet
            Console.WriteLine("Hiba történt: " + e.Message);
        }
        Console.ReadKey();


    }

    // Módosított függvény az adó kiszámítására
    static double SzamolAdot(double adosav, double alapterulet)
    {
        // Példa adószámítás - itt lehet implementálni a valós adószámítást
        // Jelenleg csak egy példa visszatérési értékkel, amelyet a program kiír

        // Példa: Az adó a házszám hosszának négyzetével szorozva az utcában levő házak számával
        // Most már az adósáv és alapterület is figyelembe van véve
        double ado = adosav * alapterulet;
        return ado;

        Console.ReadKey();

    }

        
}
